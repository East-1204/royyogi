// models/kategori.go
package models

type Kategori struct {
	ID   int    `json:"id"`
	Nama string `json:"nama"`
}
